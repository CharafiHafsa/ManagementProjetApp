#!/bin/bash

# Vérifie si l'utilisateur est root
function check_root() {
    if [ "$(id -u)" -ne 0 ]; then
        echo " Ce script doit être exécuté en tant que root."
        exit 1
    fi
}

# 1)Affiche la liste des utilisateurs avec UID > 1000
function liste_utilisateurs() {
    echo " Liste des utilisateurs avec UID > 1000 :"
    awk -F: '$3 > 1000 { print $1 }' /etc/passwd
}

#2) Vérification de l'existence d'un utilisateur
function verifier_utilisateur() {
    read -p " Entrez un nom d'utilisateur ou un UID : " identifiant

    # id
    if [[ "$identifiant" =~ ^[0-9]+$ ]]; then
        info=$(awk -F: -v uid="$identifiant" '$3 == uid { print $0 }' /etc/passwd)
    #nom
    else
        info=$(getent passwd "$identifiant")
    fi

    if [ -n "$info" ]; then
        echo " Utilisateur trouvé :"
        echo "$info"
    else
        echo " Utilisateur non trouvé."
    fi
}

# 3)Création d'un utilisateur :
function creer_utilisateur() {
    check_root
    read -p " Entrez le nom de l'utilisateur à créer : " login

    # Vérifie s'il existe déjà
    if id "$login" &>/dev/null; then
        echo " L'utilisateur '$login' existe déjà."
        return
    fi

    # Vérifie si le répertoire /home/$login existe
    if [ -d "/home/$login" ]; then
        echo " Le répertoire /home/$login existe déjà. Création annulée."
        return
    fi

    # Créer l'utilisateur avec répertoire personnel
    useradd -m "$login"
    if [ $? -eq 0 ]; then
        echo " Utilisateur '$login' créé avec succès."
    else
        echo " Échec de la création de l'utilisateur."
    fi
}

# Menu 
while true; do
    echo
    echo "========= MENU ========="
    echo "1. Afficher les utilisateurs (UID > 1000)"
    echo "2. Vérifier l'existence d'un utilisateur"
    echo "3. Créer un utilisateur"
    echo "4. Quitter"
    echo "========================"
    read -p " Choisissez une option [1-4] : " choix

    case $choix in
        1) liste_utilisateurs ;;
        2) verifier_utilisateur ;;
        3) creer_utilisateur ;;
        4) echo " script fini !"; exit 0 ;;
        *) echo " Option invalide. Veuillez entrer 1 à 4." ;;
    esac
done
