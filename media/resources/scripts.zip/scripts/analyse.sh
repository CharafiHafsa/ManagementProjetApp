#!/bin/bash
echo "Vous vous avez rentré $# paramètres."
echo "Le nom du script est $0"
if [ ! -z "$3" ]; then
  echo "Le 3ème paramètre est $3"
fi
if [ !  $# -eq 0 ]; then
  echo "Voici la liste des paramètres : $@ "
fi