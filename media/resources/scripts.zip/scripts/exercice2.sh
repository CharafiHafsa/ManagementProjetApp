
#!/bin/bash

var=30

until [[ $var -ge 0 && $var -le 20 ]]; do
    read -p "Saisir une note entre 0 et 20: " var

    if [[ $var -ge 16 && $var -le 20 ]]; then
        echo "Très bien"
    elif [[ $var -ge 14 && $var -lt 16 ]]; then
        echo "Bien"
    elif [[ $var -ge 12 && $var -lt 14 ]]; then
        echo "Assez bien"
    elif [[ $var -ge 10 && $var -lt 12 ]]; then
        echo "Moyen"
    elif [[ $var -ge 0 && $var -lt 10 ]]; then
        echo "Insuffisant"
    else
        echo "Note invalide, réessaye."
    fi
done
