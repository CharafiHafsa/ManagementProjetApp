
#!/bin/bash
date_jour=$(date +"%Y-%m-%d")
 if [ ! -d "OLD" ]; then
    mkdir OLD
    if [ $? -ne 0 ]; then
        echo "Erreur : impossible de créer le répertoire OLD."
        exit 1
    fi
  fi

for rep in  * ; do

  if [  -f "$rep" ]; then
    cp "$rep" "OLD/$rep#$date_jour"
    echo "$rep est  copié dans OLD"
  fi
done
