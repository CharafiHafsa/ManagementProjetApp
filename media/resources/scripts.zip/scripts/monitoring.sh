#!/bin/bash
while true; do 
heure=$(date +"%H:%M:%S")
# charge_processeur=$(uptime)
# memoire_disponible=$(free -h)
 charge_processeur=$(/usr/bin/uptime)
  memoire_disponible=$(/usr/bin/free -h)

echo "a $heure"
echo "la charge de processeur : $charge_processeur "
echo "la memoire disponible est : $memoire_disponible"
 echo "--------------------------"
sleep 0.5
done
