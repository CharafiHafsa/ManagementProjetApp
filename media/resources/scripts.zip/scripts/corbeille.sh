#!/bin/bash

CORBEILLE="$HOME/corbeille"

# Créer la corbeille dans le répertoire personnel si elle n'existe pas
if [ ! -d "$CORBEILLE" ]; then
    mkdir -p "$CORBEILLE"
fi

if [ $# -eq 0 ]; then
    echo "Utilisation : recycle [-l] [-r] [fichier1 fichier2 ...]"
    exit 1
fi

option_l=false
option_r=false

# Traiter les options
while getopts ":lr" option; do
    case $option in
        l)
            option_l=true
            ;;
        r)
            option_r=true
            ;;
        \?)
            echo "Option invalide : -$OPTARG"
            exit 1
            ;;
    esac
done

shift $((OPTIND - 1))  # Supprimer les options des arguments


if [[ "$option_l" = true || "$option_r" = true ]] && [[ $# -gt 0 ]]; then
    echo "Erreur : -l ou -r ne doivent pas être suivis de fichiers."
    exit 1
fi

# Lister
if [ "$option_l" = true ]; then
    echo "Contenu de la corbeille :"
    ls -l "$CORBEILLE"
    exit 0
fi

# Vider
if [ "$option_r" = true ]; then
    echo "Corbeille vidée."
    rm -rf "$CORBEILLE"/*
    exit 0
fi

# Déplacer les fichiers
if [ $# -ne 0 ]; then
    for fichier in "$@"; do
        if [ ! -f "$fichier" ]; then
            echo "$fichier : ce n'est pas un fichier"
        else
            mv "$fichier" "$CORBEILLE/"
            echo "$fichier déplacé dans la corbeille"
        fi
    done
fi
